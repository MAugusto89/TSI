for(let i = 1; i <= 10; i++){
    for(let j = 0; j <= 10; j++){
        console.log(i,'X',j,'=',i*j);
    }
    console.log('------------------------------------------------');
}